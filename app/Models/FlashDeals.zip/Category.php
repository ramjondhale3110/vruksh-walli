<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Storage;

class Category extends Model
{   
    protected $primaryKey = 'category_id';
    use HasFactory;
    protected $table = "categories";
    protected $fillable = ['category_name','priority_no','category_img'];

    public function getCategoryImgAttribute($value){
        return url('/').Storage::url($value);
    }

    public function subcategory(){
        return $this->hasMany('App\Models\SubCategory', 'sub_category_id', 'category_id');
    }
}
