<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Brand;
use App\Models\Products;
use App\Models\SubCategory;

class PublicController extends Controller
{
    public function getdashboard(Request $request){
        return view('admin.dashboard');
    }

    public function getIndex(Request $request){
        $category = Category::where('is_active',1)->get();
        $brand = Brand::where('is_active',1)->get();
        $product = Products::where('is_active',1)->orderBy('product_id','desc')->take(10)->get();
        //return $product;
        return view('index')->with('category',$category)->with('brand',$brand)->with('product',$product);
    }

    public function getProductCategory(Request $request){
        $id = $request->sub_category_id;
        $product = Products::where('sub_category_id',$id)->with('subcategory')->with('category')->get();
        return view('category')->with('product',$product);
    }

    public function getProductDetails(Request $request,$id){

        $prod = Products::where('product_id',$id)->first();
        return view('product_details')->with('prod',$prod);

    }

    
}
